def some_util_function(param):
    # This is a placeholder for a utility function
    return param * 2

def another_util_function(data):
    # This function processes data in a specific way
    return [item for item in data if item]